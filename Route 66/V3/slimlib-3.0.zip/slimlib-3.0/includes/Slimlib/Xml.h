#ifndef __Slimlib_Xml_
#define __Slimlib_Xml_
	
    #include <Slimlib/Xml/XmlParser.h>
    #include <Slimlib/Xml/XmlPattern.h>
    #include <Slimlib/Xml/XmlConfigurationFile.h>
    
#endif

