#ifndef __RootClass_Object_
#define __RootClass_Object_

class Object
{
	public:
		virtual ~Object() {}
};


#endif
